package consoCarbone;

public class BienConso {
private double montant; //d�penses annuelles de l'utilisateur
private double impact; //tonne de CO2

public BienConso(double montant) {
	this.montant = montant; 
	this.impact = this.getimpact();
}

private double getimpact() {
	return this.montant/1750;
}

//getters and stters 

public double getMontant() {
	return montant;
}

public void setMontant(double montant) {
	this.montant = montant;
}

public double getImpact() {
	return impact;
}

public void setImpact(double impact) {
	this.impact = impact;
}

//toString
public String toString() {
	   String s = "Montant des d�peses annuelles: "+this.getMontant()+"\n"+"impact: "+this.getimpact()+"\n"+"--------------------------";
	   return s;
}

}
