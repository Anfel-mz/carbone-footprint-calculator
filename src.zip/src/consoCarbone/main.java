package consoCarbone;

public class main {

	public static void main(String[] args) {
		Logement l = new Logement(23, CE.B);
		ConsoCarbone c = new ConsoCarbone ();
		Alimentation a = new Alimentation(0.2, 0.7);
		System.out.println(l.getImpact());
		System.out.println(a.getImpact());
		System.out.println(l.getId());
		System.out.println(a.getId());

	}

}
