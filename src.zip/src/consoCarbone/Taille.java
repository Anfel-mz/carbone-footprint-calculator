package consoCarbone;

public enum Taille {
P, //petite voiture 
G //grosse voiture 
}
