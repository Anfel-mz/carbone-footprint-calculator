package consoCarbone;

//les diff�rentes classes �nerg�tiques d'un logement
public enum CE {
A,B,C,D,E,F,G
}
